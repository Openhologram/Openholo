//
//  AngularC_data.cpp
//
//  Code generation for function 'AngularC_data'
//


// Include files
#include "AngularC_data.h"
#include "rt_nonfinite.h"

// Variable Definitions
omp_nest_lock_t emlrtNestLockGlobal;

// End of code generation (AngularC_data.cpp)
